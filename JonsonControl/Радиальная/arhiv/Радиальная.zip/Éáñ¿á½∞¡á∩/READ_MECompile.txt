P6NEW - �������� � �7








AUTOMATIC LOG CREATED BY FSM TOOL DURING COMPILATION

DATE: 28.01.2008
TIME: 10:31:35

 TRANSITION: 	S2 to S3
 KEY:        	S2S3
 ORIGIN: 	S2
 DESTINATION: 	S3
 DESCRIPTION: 	


 FIRST PRE-COMPILATION: 

  Input3_LOG_ON

 SECOND PRE-COMPILATION:

  Input3_LOG_ON
____________________________________________________________

 TRANSITION: 	S2 to S0
 KEY:        	S2S0
 ORIGIN: 	S2
 DESTINATION: 	S0
 DESCRIPTION: 	


 FIRST PRE-COMPILATION: 

  Input1_LOG_ON  AND  Input2_LOG_OFF  AND  Input3_LOG_OFF  AND  Input5_LOG_ON

 SECOND PRE-COMPILATION:

  Input1_LOG_ON  AND  Input2_LOG_OFF  AND  Input3_LOG_OFF  AND  Input5_LOG_ON
____________________________________________________________

 TRANSITION: 	stop to summ
 KEY:        	S2S5
 ORIGIN: 	S2
 DESTINATION: 	S5
 DESCRIPTION: 	


 FIRST PRE-COMPILATION: 

  Input2_LOG_ON

 SECOND PRE-COMPILATION:

  Input2_LOG_ON
____________________________________________________________

 TRANSITION: 	S0 to S3
 KEY:        	S0S3
 ORIGIN: 	S0
 DESTINATION: 	S3
 DESCRIPTION: 	


 FIRST PRE-COMPILATION: 

  Input3_LOG_ON

 SECOND PRE-COMPILATION:

  Input3_LOG_ON
____________________________________________________________

 TRANSITION: 	S0 to S1
 KEY:        	S0S1
 ORIGIN: 	S0
 DESTINATION: 	S1
 DESCRIPTION: 	


 FIRST PRE-COMPILATION: 

  Input1_LOG_ON  AND  Input2_LOG_OFF  AND  Input3_LOG_OFF  AND  Input4_LOG_ON  AND  Input5_LOG_ON

 SECOND PRE-COMPILATION:

  Input1_LOG_ON  AND  Input2_LOG_OFF  AND  Input3_LOG_OFF  AND  Input4_LOG_ON  AND  Input5_LOG_ON
____________________________________________________________

 TRANSITION: 	init to stop
 KEY:        	S0S2
 ORIGIN: 	S0
 DESTINATION: 	S2
 DESCRIPTION: 	


 FIRST PRE-COMPILATION: 

  Input1_LOG_OFF  OR  Input2_LOG_ON

 SECOND PRE-COMPILATION:

  Input1_LOG_OFF  OR  Input2_LOG_ON
____________________________________________________________

 TRANSITION: 	S1 to S3
 KEY:        	S1S3
 ORIGIN: 	S1
 DESTINATION: 	S3
 DESCRIPTION: 	


 FIRST PRE-COMPILATION: 

  Input3_LOG_ON

 SECOND PRE-COMPILATION:

  Input3_LOG_ON
____________________________________________________________

 TRANSITION: 	S1 to S4
 KEY:        	S1S4
 ORIGIN: 	S1
 DESTINATION: 	S4
 DESCRIPTION: 	


 FIRST PRE-COMPILATION: 

  Input1_LOG_OFF  AND  Input2_LOG_OFF  AND  Input3_LOG_OFF  AND  Input4_LOG_OFF

 SECOND PRE-COMPILATION:

  Input1_LOG_OFF  AND  Input2_LOG_OFF  AND  Input3_LOG_OFF  AND  Input4_LOG_OFF
____________________________________________________________

 TRANSITION: 	S3 to S2
 KEY:        	S3S2
 ORIGIN: 	S3
 DESTINATION: 	S2
 DESCRIPTION: 	


 FIRST PRE-COMPILATION: 

  Input3_LOG_OFF

 SECOND PRE-COMPILATION:

  Input3_LOG_OFF
____________________________________________________________

 TRANSITION: 	S4 to S3
 KEY:        	S4S3
 ORIGIN: 	S4
 DESTINATION: 	S3
 DESCRIPTION: 	


 FIRST PRE-COMPILATION: 

  Input3_LOG_ON

 SECOND PRE-COMPILATION:

  Input3_LOG_ON
____________________________________________________________

 TRANSITION: 	S4 to S2
 KEY:        	S4S2
 ORIGIN: 	S4
 DESTINATION: 	S2
 DESCRIPTION: 	


 FIRST PRE-COMPILATION: 

  Input1_LOG_OFF  AND  Input2_LOG_OFF  AND  Input3_LOG_OFF  AND  Input4_LOG_OFF  AND  Input5_LOG_OFF

 SECOND PRE-COMPILATION:

  Input1_LOG_OFF  AND  Input2_LOG_OFF  AND  Input3_LOG_OFF  AND  Input4_LOG_OFF  AND  Input5_LOG_OFF
____________________________________________________________

 TRANSITION: 	summ to stop
 KEY:        	S5S2
 ORIGIN: 	S5
 DESTINATION: 	S2
 DESCRIPTION: 	


 FIRST PRE-COMPILATION: 

  Input2_LOG_OFF

 SECOND PRE-COMPILATION:

  Input2_LOG_OFF
____________________________________________________________



Linea:
Key:
Linea:
Key:
Linea:
Key:
Linea:3
Key:I0
Linea:4
Key:I0
Linea:5
Key:I0
Linea:6
Key:I0
Linea:
Key:
Linea:8
Key:S2
Linea:9
Key:S2
Linea:10
Key:S2
Linea:11
Key:S2
Linea:12
Key:S2
Linea:13
Key:S2
Linea:14
Key:S2
Linea:
Key:
Linea:16
Key:S2
Linea:17
Key:S2
Linea:18
Key:S2
Linea:19
Key:S2
Linea:20
Key:S2
Linea:21
Key:S2
Linea:22
Key:S2
Linea:23
Key:S2
Linea:24
Key:S2
Linea:25
Key:S2
Linea:26
Key:S2
Linea:27
Key:S2
Linea:28
Key:S2
Linea:
Key:
Linea:30
Key:S0
Linea:31
Key:S0
Linea:32
Key:S0
Linea:33
Key:S0
Linea:34
Key:S0
Linea:35
Key:S0
Linea:36
Key:S0
Linea:
Key:
Linea:38
Key:S0
Linea:39
Key:S0
Linea:40
Key:S0
Linea:41
Key:S0
Linea:42
Key:S0
Linea:43
Key:S0
Linea:44
Key:S0
Linea:45
Key:S0
Linea:46
Key:S0
Linea:47
Key:S0
Linea:48
Key:S0
Linea:49
Key:S0
Linea:50
Key:S0
Linea:51
Key:S0
Linea:52
Key:S0
Linea:
Key:
Linea:54
Key:S1
Linea:55
Key:S1
Linea:56
Key:S1
Linea:57
Key:S1
Linea:58
Key:S1
Linea:59
Key:S1
Linea:60
Key:S1
Linea:
Key:
Linea:62
Key:S1
Linea:63
Key:S1
Linea:64
Key:S1
Linea:65
Key:S1
Linea:66
Key:S1
Linea:67
Key:S1
Linea:68
Key:S1
Linea:69
Key:S1
Linea:70
Key:S1
Linea:71
Key:S1
Linea:72
Key:S1
Linea:
Key:
Linea:74
Key:S3
Linea:75
Key:S3
Linea:76
Key:S3
Linea:77
Key:S3
Linea:78
Key:S3
Linea:79
Key:S3
Linea:80
Key:S3
Linea:
Key:
Linea:82
Key:S3
Linea:83
Key:S3
Linea:84
Key:S3
Linea:85
Key:S3
Linea:86
Key:S3
Linea:87
Key:S3
Linea:
Key:
Linea:89
Key:S4
Linea:90
Key:S4
Linea:91
Key:S4
Linea:92
Key:S4
Linea:93
Key:S4
Linea:94
Key:S4
Linea:95
Key:S4
Linea:
Key:
Linea:97
Key:S4
Linea:98
Key:S4
Linea:99
Key:S4
Linea:100
Key:S4
Linea:101
Key:S4
Linea:102
Key:S4
Linea:103
Key:S4
Linea:104
Key:S4
Linea:105
Key:S4
Linea:106
Key:S4
Linea:107
Key:S4
Linea:108
Key:S4
Linea:
Key:
Linea:110
Key:S5
Linea:111
Key:S5
Linea:112
Key:S5
Linea:113
Key:S5
Linea:114
Key:S5
Linea:115
Key:S5
Linea:116
Key:S5
Linea:
Key:
Linea:118
Key:S5
Linea:119
Key:S5
Linea:120
Key:S5
Linea:121
Key:S5
Linea:122
Key:S5
Linea:123
Key:S5
Linea:
Key:
Linea:125
Key:G
Linea:126
Key:G
Linea:127
Key:I0
